This is a Discord bot. This portfolio item was made with the purpose of demonstrating my ability to pick up, learn and use APIs (working on projects that connect to already existing platforms that allow external applications).
bot.py contains all the code of the Discord bot.
The bot has following capabilities:
1. !ping                       - This command gets you the following reply: "pong" (a common Discord bot command)
2. !rps / !rockpaperscissors   - This command lets you play rock paper scissors with the bot.
3. !rr / !russianroulette      - This command tells you that you died 1 out of 6 times.
4. !cf / !coinflip             - This command gives you either tails or heads.
5. !help                       - This command gives you all of the aforementioned commands in a list.

---------------------------------------------------------------------------------------------------------------------------------------
NOTE:
I do not host this bot, so to test its capabilities, you will have to host it on your own.
Tutorial (Proceeding may be difficult if inexperienced):
1. Open up the Discord creator portal.
2. Create an application.
3. Go to the "bot" section of your application.
4. Click on reset token and copy it.
5. Open the botToken.py file by right clicking and clicking "edit".
6. Paste your token in between the two quotation marks.
From here on out, you have two options.
A. Download Python, pip and discord.py to run the program on your local machine (EXPERTS ONLY).
B. Find a hosting platform (such as Discloud) to host the code for you.
B1. If you are going to go the B route, first, drop all files (not folders) except README into a zipfile by selecting all of them, left clicking and "sending to" a compressed file.
B2. Create a Discloud account and add an application through your dashboard.
B3. Drop in the zipfile.
