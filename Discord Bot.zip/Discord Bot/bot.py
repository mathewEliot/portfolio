import discord
import random
from discord.ext import commands

from botToken import *

client = commands.Bot(command_prefix = "!", intents= discord.Intents.all())
client.remove_command('help')

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Activity(type = discord.ActivityType.listening, name = "you!"))
    print("  I'm online")


class rock_paper_scissors(discord.ui.View):
    def __init__(self):
        super().__init__()
        self.value = None
        self.embed = None
        self.picked = None
        self.catalyst = None
        self.choices = [0, 1, 2]
        self.dict = {0: "🪨", 1: "📰", 2: "✂️"}
        self.bot_picked = random.randint(0,2)
        for i in range(3):
            self.add_item(discord.ui.Button(label=self.dict[i], style=discord.ButtonStyle.gray, custom_id=f"button_{i}"))
            self.children[-1].callback = self.once_picked
    async def once_picked(self, interaction: discord.Interaction):
        if interaction.user.id != self.catalyst:
            await interaction.response.defer()
            return
        self.picked = int(interaction.data['custom_id'].split("_")[-1])
        self.children[self.picked].style = discord.ButtonStyle.blurple
        self.embed.title = f"Rock Paper Scissors - i picked {self.dict[self.bot_picked]}"
        if self.picked - 1 == self.bot_picked:
            self.embed.description = "You won!"
            self.embed.color = 0x00FF00
        elif self.picked == self.bot_picked:
            self.embed.description = "You drew!"
            self.embed.color = 0xFFFF00
        else:
            self.embed.description = "You lost!"
            self.embed.color = 0xFF0000
        for child in self.children:
            child.disabled = True
        await interaction.response.defer()
        await interaction.message.edit(view=self, embed=self.embed)
        return


async def send_rps(ctx):
    view = rock_paper_scissors()
    view.catalyst = ctx.author.id
    view.embed = discord.Embed(color=discord.Color.dark_grey(), title="Rock Paper Scissors", description="Pick")
    await ctx.reply(view=view, embed=view.embed)
async def send_help(ctx):
    embed = discord.Embed(color=discord.Color.dark_grey(), title="Commands", description="!ping\n!rps / !rockpaperscissors\n!rr / !russianroulette\n!cf / !coinflip")
    await ctx.reply(embed=embed)
async def send_cf(ctx):
    if random.randint(0,1) == 0:
        await ctx.reply("heads!")
    else:
        await ctx.reply("tails!")
async def send_rr(ctx):
    if random.randint(0,5) == 0:
        await ctx.reply("you died")
    else:
        await ctx.reply("didn't fire... phew")


@client.command()
async def ping(ctx):
    await ctx.reply("pong!")
@client.command()
async def rps(ctx):
    await send_rps(ctx)
@client.command() 
async def rockpaperscissors(ctx):
    await send_rps(ctx)
@client.command()
async def help(ctx):
    await send_help(ctx)
@client.command()
async def h(ctx):
    await send_help(ctx)
@client.command()
async def cf(ctx):
    await send_cf(ctx)
@client.command()
async def coinflip(ctx):
    await send_cf(ctx)
@client.command()
async def rr(ctx):
    await send_rr(ctx)
@client.command()
async def russianroulette(ctx):
    await send_rr(ctx)


client.run(tokenKey)
